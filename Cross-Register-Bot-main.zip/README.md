# Kurulum
* [Node.JS](https://nodejs.org/en/) Cihazınınızda Node kurulu olduğundan emin olun!
* Yeşil Code butonuna basın ve Downland zip seçeneğine tıklayın indirme işlemini bekleyin.
* İndirme işlemi tamamlandığında zipin üstüne gelerek buraya çıkartı işaretleyin.
* Klasörü çıkardıkdan sonra `settings.js` adlı dosyayı doldurmanız gerekmekte doğru bir şekilde doldurduğunuzdan emin olun.
* `settings.js` dosyasında bulunan `mongoURL` kısmına mongo linkinizi girin, Mongo linki almayı bilmiyorsanız [Tıklayın](https://www.youtube.com/watch?v=s_-gJn9GDus)
* Terminali açıp `npm install` yazıp gerekli modüllerin inmesini bekleyin indikten sonra `npm test` yazarak botu başlatın!
* İNTENTLERİ AÇMAYI UNUTMAYIN !!!!!!!
# Kullanım
* Bottaki gerekli kurulumları yaptıktan sonra `.isim-mod` & `.taglıalım` komutları ile botu özelleştirebilirsiniz.
* Botu dilediğiniz gibi kullanabilirsiniz

# İletişim
* Botla ilgili her hangi bir hata veya soru için [Discord Adresim](https://discord.com/users/799237103195127848)'den ulaşabilirsiniz.
* Yardım almak için [Serendia Squad](https://discord.gg/ATFY2ZzREb) sunucusunu ziyaret edebilirsiniz.
